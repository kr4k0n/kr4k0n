"""core subpackage"""
from Ingram.core.main import Core