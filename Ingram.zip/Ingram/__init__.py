"""Ingram package"""
import warnings; warnings.filterwarnings("ignore")