"""some middlewares"""
from Ingram.middleware.detect import device_detect, port_detect
from Ingram.middleware.status import status_bar
from Ingram.middleware.shop import snapshot